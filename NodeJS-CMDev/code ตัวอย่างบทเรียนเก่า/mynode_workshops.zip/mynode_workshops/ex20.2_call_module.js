var obj = require('./ex20.1_export_module');
obj.function1();
obj.function2("chaiyasit.t@gmail.com","1234");